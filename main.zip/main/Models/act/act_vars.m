actData.dElev.Max   = 25;       % [deg] Max Elevator Deflection
actData.dElev.Min   = -25;      % [deg] Min Elevator Deflection
actData.dAil.Max    = 21.5;     % [deg] Max Aileron Deflection
actData.dAil.Min    = -21.5;    % [deg] Min Aileron Deflection
actData.dRud.Max    = 30;       % [deg] Max Rudder Deflection
actData.dRud.Min    = -30;      % [deg] Min Rudder Deflection 
actData.dLEF.Max    = 25;       % [deg] MAX Leading Edge Flap Defl. 
actData.dLEF.Min    = -25;      % [deg] Min Leading Edge Flap Defl.
% Define rate limiters
actData.dElev.rateLim_rps   = 60*(pi/180);  % [r/s]
actData.dAil.rateLim_rps    = 80*(pi/180);  % [r/s]
actData.dRud.rateLim_rps    = 120*(pi/180); % [r/s]

