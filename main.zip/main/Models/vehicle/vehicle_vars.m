%% Load Bus Objects
vehicle_BusObjects;

