%% Define Bus Objects
mass_BusObjects;

%% Define Mass Parameters
massData.weight_lbm = 20500;
massData.mass_sl    = massData.weight_lbm/32.2;
massData.ixx_slft2  = 9456;
massData.ixy_slft2  = 0;
massData.ixz_slft2  = 982;
massData.iyy_slft2  = 55814;
massData.iyx_stft2  = 0;
massData.iyz_slft2  = 0;
massData.izz_slft2  = 63100;
% MOI Matrix
massData.MOI_slft2 = [massData.ixx_slft2 massData.ixy_slft2 massData.ixz_slft2;...
                      massData.iyx_stft2 massData.iyy_slft2 massData.iyz_slft2;...
                      massData.ixz_slft2 massData.iyz_slft2 massData.izz_slft2];
% Define CG information
massData.xcg_ft     = 0.3*aeroData.CREF;
massData.ycg_ft     = 0;
massData.zcg_ft     = 0;

%% Initialize Bias 
massData.bias.weight_lbm    = 0;
massData.bias.xcg_ft        = 0;
massData.bias.ycg_ft        = 0;
massData.bias.zcg_ft        = 0;