ft2m = 0.3048;
d2r = pi/180;
r2d = 180/pi;
lbf2N = 4.44822;