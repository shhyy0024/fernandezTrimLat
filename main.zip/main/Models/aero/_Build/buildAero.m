%%
clear rawData aeroData out
%% Load data
rawData = load('F16AeroDataInterpolants.mat');

%% Base Coefficent
% Store breakpoints (same for all coeffs)
aeroData.base.bp.alpha_deg  = rawData.F16AeroData.Cx.GridVectors{1};
aeroData.base.bp.beta_deg   = rawData.F16AeroData.Cx.GridVectors{2};
aeroData.base.bp.de_deg     = rawData.F16AeroData.Cx.GridVectors{3};
aeroData.base.bp.de_deg2    = rawData.F16AeroData.Cn.GridVectors{3};

% Store base coefficent (body)
aeroData.base.Cx = rawData.F16AeroData.Cx.Values;
aeroData.base.Cy = rawData.F16AeroData.Cy.Values;
aeroData.base.Cz = rawData.F16AeroData.Cz.Values;
aeroData.base.Cm = rawData.F16AeroData.Cm.Values;
aeroData.base.Cn = rawData.F16AeroData.Cn.Values;
aeroData.base.Cl = rawData.F16AeroData.Cl.Values;

%% LEF Deflection Increment
% Store breakpoints (same for all LEF coeffs)
aeroData.LEF.bp.alpha_deg   = rawData.F16AeroData.Cx_lef.GridVectors{1};
aeroData.LEF.bp.beta_deg    = rawData.F16AeroData.Cx_lef.GridVectors{2};

% Store LEF coefficent
aeroData.LEF.Cx = rawData.F16AeroData.Cx_lef.Values;
aeroData.LEF.Cy = rawData.F16AeroData.Cy_lef.Values;
aeroData.LEF.Cz = rawData.F16AeroData.Cz_lef.Values;
aeroData.LEF.Cm = rawData.F16AeroData.Cm_lef.Values;
aeroData.LEF.Cn = rawData.F16AeroData.Cn_lef.Values;
aeroData.LEF.Cl = rawData.F16AeroData.Cl_lef.Values;

%% Dynamic Derivatives
% Store breakpoints (same for all coeffs)
aeroData.dynDer.bp.alpha_deg = rawData.F16AeroData.Cxq.GridVectors{1};

% Store dynamic derivatives
aeroData.dynDer.Cxq = rawData.F16AeroData.Cxq.Values;
aeroData.dynDer.Cyp = rawData.F16AeroData.Cyp.Values;
aeroData.dynDer.Cyr = rawData.F16AeroData.Cyr.Values;
aeroData.dynDer.Czq = rawData.F16AeroData.Czq.Values;
aeroData.dynDer.Cmq = rawData.F16AeroData.Cmq.Values;
aeroData.dynDer.Cnp = rawData.F16AeroData.Cnp.Values;
aeroData.dynDer.Cnr = rawData.F16AeroData.Cnr.Values;
aeroData.dynDer.Clp = rawData.F16AeroData.Clp.Values;
aeroData.dynDer.Clr = rawData.F16AeroData.Clr.Values;

%% Dynamic Derivative w/LEF
% Store breakpoints (same for all coeffs)
aeroData.dynDerLEF.bp.alpha_deg = rawData.F16AeroData.deltaCxq_lef.GridVectors{1};

% Store data
aeroData.dynDerLEF.dCxq = rawData.F16AeroData.deltaCxq_lef.Values;
aeroData.dynDerLEF.dCyp = rawData.F16AeroData.deltaCyp_lef.Values;
aeroData.dynDerLEF.dCyr = rawData.F16AeroData.deltaCyr_lef.Values;
aeroData.dynDerLEF.dCzq = rawData.F16AeroData.deltaCzq_lef.Values;
aeroData.dynDerLEF.dCmq = rawData.F16AeroData.deltaCmq_lef.Values;
aeroData.dynDerLEF.dCnp = rawData.F16AeroData.deltaCnp_lef.Values;
aeroData.dynDerLEF.dCnr = rawData.F16AeroData.deltaCnr_lef.Values;
aeroData.dynDerLEF.dClp = rawData.F16AeroData.deltaClp_lef.Values;
aeroData.dynDerLEF.dClr = rawData.F16AeroData.deltaClr_lef.Values;

%% Aileron Effects
% Store breakpoints (same for all coeffs)
aeroData.dAil20.bp.alpha_deg    = rawData.F16AeroData.Cy_a20.GridVectors{1};
aeroData.dAil20.bp.beta_deg     = rawData.F16AeroData.Cy_a20.GridVectors{2};

% Store data
aeroData.dAil20.Cy = rawData.F16AeroData.Cy_a20.Values;
aeroData.dAil20.Cn = rawData.F16AeroData.Cn_a20.Values;
aeroData.dAil20.Cl = rawData.F16AeroData.Cl_a20.Values;

%% Aileron w/LEF Effects
% Store breakpoints (same for all coeffs)
aeroData.dAil20LEF.bp.alpha_deg    = rawData.F16AeroData.Cy_a20_lef.GridVectors{1};
aeroData.dAil20LEF.bp.beta_deg     = rawData.F16AeroData.Cy_a20_lef.GridVectors{2};

% Store data
aeroData.dAil20LEF.Cy = rawData.F16AeroData.Cy_a20_lef.Values;
aeroData.dAil20LEF.Cn = rawData.F16AeroData.Cn_a20_lef.Values;
aeroData.dAil20LEF.Cl = rawData.F16AeroData.Cl_a20_lef.Values;

%% Rudder Effects
% Store breakpoints (same for all coeffs)
aeroData.dRud30.bp.alpha_deg    = rawData.F16AeroData.Cy_r30.GridVectors{1};
aeroData.dRud30.bp.beta_deg     = rawData.F16AeroData.Cy_r30.GridVectors{2};

% Store data
aeroData.dRud30.Cy  = rawData.F16AeroData.Cy_r30.Values;
aeroData.dRud30.Cn  = rawData.F16AeroData.Cn_r30.Values;
aeroData.dRud30.Cl  = rawData.F16AeroData.Cl_r30.Values;

%% Beta Effects
% Store breakpoints
aeroData.beta.bp.alpha_deg = rawData.F16AeroData.deltaCnbeta.GridVectors{1};

% Store data
aeroData.beta.Cn_beta = rawData.F16AeroData.deltaCnbeta.Values;
aeroData.beta.Cl_beta = rawData.F16AeroData.deltaClbeta.Values;

%% Pitch Moment 
% Store breakpoints
aeroData.dCm.bp.alpha_deg = rawData.F16AeroData.deltaCm.GridVectors{1};
aeroData.etaEl.bp.de_deg = rawData.F16AeroData.eta_el.GridVectors{1};

% Store data
aeroData.dCm.Cm         = rawData.F16AeroData.deltaCm.Values;
aeroData.etaEl.etaEl    = rawData.F16AeroData.eta_el.Values;

%% Save data 
save('F16_aeroData','aeroData')

clear rawData