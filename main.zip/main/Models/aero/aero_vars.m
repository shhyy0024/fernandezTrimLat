%% Load Data
load('F16_aeroData.mat')

%% Load Bus Objects
aero_BusObjects;

%% Define Aero Parameters
aeroData.SREF = 300;                % [ft^2]
aeroData.BREF = 30;                 % [ft]
aeroData.CREF = 11.32;              % [ft]
aeroData.XREF = 0.35*aeroData.CREF; % [ft] Reference point for aero data
aeroData.YREF = 0;                  % [ft] Reference point for aero data
aeroData.ZREF = 0;                  % [ft] Reference point for aero data

massData.xcg_ft = 0.3*aeroData.CREF;
massData.ycg_ft = 0;
massData.zcg_ft = 0;