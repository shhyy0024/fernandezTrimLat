%% Load Bus Objects
atmo_BusObjects;

%% Define Sea-Level Parameters
atmoData.a0_fps  = 1116.35;
atmoData.p0_psi  = 14.69597;