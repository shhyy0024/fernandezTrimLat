%% Load Bus Objects
prop_BusObjects;

%% Read in Prop Data
load('F16_prop.mat');

%% Define Prop Parameters
propData.initThrust_lbf = 3400;     % Thrust idle (thr = 0) (20% Max Thrust)
propData.maxThrust_lbf  = 17000;    % Max Thrust (no AB) at thr = 1 (100% max thrust no AB)
propData.tau_s          = 1;
propData.TSFC           = 0.7;      % [lbm/(lbf*hr)] 
propData.thrustRat      = 1;        % Assuming perfect conditions
