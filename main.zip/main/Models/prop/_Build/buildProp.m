%% Clear data
clear rawData propData

%% Read Data from Prop Excel
rawData = readmatrix('F16_Prop.xlsx');

%% Store Breakpoints
propData.bp.throttle    = unique(rawData(:,1));
propData.bp.alt_ft      = unique(rawData(:,2));
propData.bp.Mach        = unique(rawData(:,3));

%% Reshape Thrust Table 
propData.thrust_lbf = reshape(rawData(:,4),numel(propData.bp.Mach),...
    numel(propData.bp.alt_ft),numel(propData.bp.throttle));

%% Save Data
save('F16_prop.mat','propData');